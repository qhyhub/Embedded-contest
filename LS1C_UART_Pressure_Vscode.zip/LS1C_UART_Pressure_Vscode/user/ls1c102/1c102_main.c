/******************************************************
 * 实验名称：温湿度监测实验
 *
 * 实验准备：龙芯1C102开发板，ESP8266模块，通讯底板，
            温湿度传感器，4P小白线，3P小白线
 *
 * 实验接线：ESP8266模块接到龙芯1C102开发板的UART0接口，
            使用通讯底板连接ESP8266模块的TXD和RXD接口
            到开发板的GPIO_Pin_06和GPIO_Pin_07接口，
 *
 * 实验现象：通过ESP8266上传温湿度数据至云平台
******************************************************/
#include "ls1x.h"
#include "Config.h"
#include "ls1x_gpio.h"
#include "ls1x_latimer.h"
#include "esp8266.h"
#include "ls1c102_interrupt.h"
#include "iic.h"
#include "oled.h"
#include "BEEP.h"
#include "key.h"
#include "led.h"
#include "hx711.h"
#include "ls1c102_ptimer.h"
#define LED 20

char str[50];
int medleng = 0;
uint8_t Pi_flag = 0;
uint32_t weight;
uint32_t pi_weight;
uint32_t try;
int Weight_Value;
uint8_t data[8] = {0x55, 0xAA, 0x00, 0x00, 0x00, 0x00, 0x00, 0xBB}; // 温湿度数据上云平台    数据包

extern int duty;
bool flag = 0;
uint8_t Keynum = 0;

int main(int arg, char *args[])
{
    KEY_Init();
    SystemClockInit(); // 时钟等系统配置
    GPIOInit();        // io配置
    OLED_Init();
    BEEP_Init();
    hx711_Init();
    Get_Maopi();
    EnableInt(); // 开总中断
    timer_init(100);
    timer_init(100); // set time 0.1ms
    duty = 15;       // 初始设置90度
    delay_ms(1000);
    Uart0_init(9600);                        // 串口0初始化，io06 io07   串口初始化需要在开启EnableInt之后
    OLED_Show_Str(15, 0, "请适量取药", 16);  // OLED显示界面
    OLED_Show_Str(15, 3, "重量:     g", 16); // OLED显示界面
    while (1)
    {
        Weight_Value = Get_Weight();
        sprintf(str, "%3d", Weight_Value / 10);
        OLED_Show_Str(60, 3, str, 16);

        data[2] = (Weight_Value / 10) / 256;
        data[3] = (Weight_Value / 10) % 256;
        // delay_ms(1500);
        data[6] = (data[2] + data[3] + data[4] + data[5]) % 256; // 计算校验和
        printf("%s", data);
        UART_SendDataALL(UART0, data, 8);

        if ((Weight_Value / 10) < 50)
        {
            BEEP_ON;
        }
        else
        {
            BEEP_OFF;
        }

        delay_ms(500);
        Keynum = KEY_Check();
        switch (Keynum)
        {
        case 1:
            duty = 5; // 初始设置0度
            delay_ms(1000);
            break;
        case 2:
            duty = 15; // 初始设置90度
            delay_ms(1000);
            break;
        }
    }
    return 0;
}
