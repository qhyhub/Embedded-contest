/***************************************************************************************
 * 实验名称：PWM舵机控制实验
 *
 * 实验准备：龙芯1C102开发板, 舵机, 杜邦线
 *
 * 实验接线：外接舵机，连接到P7上
 *
 * 实验现象：舵机控制信号为周期20ms的脉宽调制，本实验设置定时器为100us
            对于本次实验舵机控制： 高电平  0.5ms 0°    定时器计数5
                                  1.0ms 45°   定时器计数10
                                  1.5ms 90°   定时器计数15
                                  2.0ms 135°  定时器计数20
                                  2.5ms 180°  定时器计数25
 * 说   明：定时器中断服务函数为intc_handler，该函数在1C102_Interrupt.c文件的第366行
****************************************************************************************/
#include "ls1x.h"
#include "Config.h"
#include "ls1x_gpio.h"
#include "ls1x_latimer.h"
#include "ls1c102_ptimer.h"
#include "iic.h"
#include "key.h"
extern int duty;
bool flag = 0;
uint8_t Keynum = 0;

int main(int arg, char *args[])
{
    KEY_init();                 
    GPIOInit();                                 // io配置
    EnableInt();                               // 开总中断
    timer_init(1000);
    timer_init(100); // set time 0.1ms
    duty = 15; // 初始设置90度
    delay_ms(1000);
    while (1)
    {
    Keynum = KEY_Check();
    switch(Keynum)
        {
            case 1: duty = 5;        // 初始设置0度
                    // delay_ms(1000);
            break;
            case 2: duty = 15;       // 初始设置90度
                    // delay_ms(1000);
            break;
        }
    } 
    //  duty = 25; // 初始设置180度
    //  delay_ms(1000);
    return 0;
}
