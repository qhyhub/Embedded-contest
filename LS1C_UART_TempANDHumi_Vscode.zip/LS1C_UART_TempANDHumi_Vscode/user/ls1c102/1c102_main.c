/******************************************************
 * 实验名称：温湿度监测实验
 *
 * 实验准备：龙芯1C102开发板，ESP8266模块，通讯底板，
            温湿度传感器，4P小白线，3P小白线
 *
 * 实验接线：ESP8266模块接到龙芯1C102开发板的UART0接口，
            使用通讯底板连接ESP8266模块的TXD和RXD接口
            到开发板的GPIO_Pin_06和GPIO_Pin_07接口，
 *
 * 实验现象：通过ESP8266上传温湿度数据至云平台
******************************************************/
#include "ls1x.h"
#include "Config.h"
#include "ls1x_gpio.h"
#include "ls1x_latimer.h"
#include "esp8266.h"
#include "ls1c102_interrupt.h"
#include "iic.h"
#include "oled.h"
#include "dht11.h"
#include "BEEP.h"
#include "key.h"
#include "led.h"
#include "ls1c102_ptimer.h"

#define LED 20

char str[50];
static uint16_t temperature;
static uint16_t humidity;
extern int duty;
bool flag = 0;
uint8_t Keynum = 0;
char temp[30];
uint8_t data[8] = {0x55, 0xAA, 0x00, 0x00, 0x00, 0x00, 0x00, 0xBB}; //温湿度数据上云平台    数据包

int main(int arg, char *args[])
{
    SystemClockInit(); // 时钟等系统配置
    GPIOInit();  
    KEY_Init();
    BEEP_Init();      // io配置
    OLED_Init();
    IIC_Init();
    EnableInt(); // 开总中断
    // Queue_Init(&Circular_queue);
    Uart0_init(9600); // 串口0初始化，io06 io07   串口初始化需要在开启EnableInt之后

    OLED_Show_Str(10, 0, "温湿度监测实验", 16); // OLED显示界面

    while (DHT11_Init()) // 检测是否接入温湿度传感器
    {
        OLED_Show_Str(10, 4, "未检测到传感器", 16); // OLED显示界面
    }
    // OLED_Show_Str(0, 4, "                ", 16); // OLED显示界面
    OLED_Show_Str(20, 3, "温度:     ℃", 16);     // OLED显示界面
    OLED_Show_Str(20, 6, "湿度:     %RH", 16);
    while (1)
    {
        DHT11_Read_Data(&temperature, &humidity); // 读取温湿度值

        data[2] = temperature / 10;     //将温湿度数据存放至数据包中
        data[3] = humidity / 10;

        sprintf(str, "%2d", temperature / 10);     
        OLED_Show_Str(70, 3, str, 16);           //显示温度
        sprintf(str, "%2d", humidity / 10);
        OLED_Show_Str(70, 6, str, 16);           //显示湿度

        if(wifi_connected == 0)
        {
            if(esp8266_check_cmd('T'))     //当收到'T'字符时，表示ESP8266连接成功
            {
                OLED_Clear(); // OLED显示界面
                wifi_connected = 1;
                OLED_Show_Str(12, 3, "未连接到WIFI", 16);
                delay_ms(1000);
                OLED_Clear(); // OLED显示界面
                delay_ms(500);
                OLED_Show_Str(10, 0, "温湿度监测实验", 16); // OLED显示界面
                OLED_Show_Str(20, 3, "温度:    ℃", 16);     // OLED显示界面
                OLED_Show_Str(20, 6, "湿度:    %RH", 16);
                gpio_write_pin(LED, 1);
                BEEP_ON;
                delay_ms(500);
                BEEP_OFF;

            }
        }
        if(wifi_connected == 1)
        {
            delay_ms(1500);
            data[6] = (data[2] + data[3] + data[4] + data[5]) % 256;   //计算校验和
            printf("%s",data);
            UART_SendDataALL(UART0, data, 8);
        }
        // timer_init(100); // set time 0.1ms
        if ((humidity/10)>75||(temperature/10)>40)
        {
            BEEP_ON;
        }else
        {
            BEEP_OFF;
        }
        
        
    }

    return 0;
}
